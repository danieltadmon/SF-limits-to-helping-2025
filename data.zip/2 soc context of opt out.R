########################################################################################################################
# Daniel Tadmon
# Code for "Limits to Helping in a Helping Profession: The Social Context of Psychiatrist Opt-Out from Public Insurance"
# Published in Social Forces 2025 (https://academic.oup.com/sf/advance-article-abstract/doi/10.1093/sf/soaf107/8214142)
########################################################################################################################

library(sf)
library(spsur)
library(future)

georgia_tracts <- st_read(here("data", "Georgia 2023 Census tract SHP", "tl_2023_13_tract.shp"))

temp_df <- df[ , c("GEOID", "acs_pop", independent_variables$variable, dependent_variables$variable)] %>% 
  dplyr::select(-ruca) %>% 
  drop_na()

GEOID_string <- paste0(paste0("^", 
                              temp_df %>% 
                                pull(GEOID)), collapse = "|")

tract_shp <- georgia_tracts %>%
  filter(str_detect(GEOID, GEOID_string)) 

# connecting islands: https://gis.stackexchange.com/q/413159
add_nb <- function(x){
  
  queen_nb <- spdep::poly2nb(x, queen = TRUE)
  
  count = spdep::card(queen_nb)
  if(!any(count==0)){
    return(queen_nb)
  }
  
  ## get nearest neighbour index, use centroids:
  nnbs = spdep::knearneigh(st_coordinates(st_centroid(x)))$nn
  
  no_edges_from = which(count==0)
  for(i in no_edges_from){
    queen_nb[[i]] = nnbs[i]
  }
  return(queen_nb)
}

new_queen_nb <- add_nb(tract_shp)
W <- spdep::nb2listw(new_queen_nb, style="B", zero.policy=TRUE)
wm <- spdep::nb2mat(new_queen_nb, style = "B", zero.policy = TRUE)
rwm <- spdep::mat2listw(wm, style = "B")

spsur_func <- function(DV1, DV2, IV){
  
  formula_string <- paste(DV1, "|", DV2, "~", IV)
  Tformula <- as.formula(formula_string)
  
  spcSUR.slm <- spsur::spsurml(formula = Tformula,
                       data = temp_df,
                       type = "slm",
                       listw = rwm)
  
  R1 <- matrix(c(0, 1, 0, -1), nrow = 1)
  b1 <- matrix(0, ncol = 1)
  Wald_beta <- wald_betas(obj = spcSUR.slm,
                          R = R1,
                          b = b1)
  
  coefficients <- spcSUR.slm$coefficients[!str_detect(names(spcSUR.slm$coefficients), "Intercept")]
  standard_errors <- c(spcSUR.slm$rest.se[2], spcSUR.slm$rest.se[4])
  
  return(data.frame(DV1_coef = coefficients[1],
                    DV1_se = standard_errors[1],
                    DV2_coef = coefficients[2],
                    DV2_se = standard_errors[2],
                    wald_test_p_value = Wald_beta$p.value,
                    R2_pool = spcSUR.slm$R2['R2_pool']))
  
}

plan(multisession, workers = 6)

combinations_df_spatial <- tribble(
  ~DV1, ~DV2,
  "psychiatrist_medicaid_3sfca_std", "psychiatrist_NOT_medicaid_3sfca_std",
  "psychiatrist_medicare_3sfca_std", "psychiatrist_NOT_medicare_3sfca_std"
)

combinations_df_spatial <- expand_grid(combinations_df_spatial,
                                       IV = independent_variables$variable)

combinations_df_spatial <- combinations_df_spatial %>% 
  filter(IV != "ruca")

combinations_df_spatial <- combinations_df_spatial %>% 
  mutate(results = furrr::future_pmap(list(DV1, DV2, IV), spsur_func)) %>% 
  unnest(results)

variable_renaming_func <- function(x){
  
  temp_tibble <- bind_rows(dependent_variables, independent_variables, independent_variables_places)
  temp_tibble <- bind_rows(temp_tibble, 
                           tibble(variable = c("rucaMicropolitan", "rucaSmall town and rural"),
                           name = c("Micropolitan", "Small town and rural"))
  )
  
  x <- temp_tibble$name[temp_tibble$variable == x]
  return(x)
  
}

combinations_df_spatial <- combinations_df_spatial %>% 
  mutate(across(matches("^DV\\d$|^IV$"), ~ furrr::future_map_chr(.x, variable_renaming_func))) 

combinations_df_spatial$IV <- factor(str_remove(combinations_df_spatial$IV, "\\(.+\\)"), 
                                     levels = str_remove(independent_variables_factor, "\\(.+\\)"))

combinations_df_spatial %>% 
  mutate(DV1 = case_when(str_detect(DV1, "Medicaid") ~ "Medicaid",
                         str_detect(DV1, "Medicare") ~ "Medicare",
                         str_detect(DV1, "any public") ~ "Any public\ninsurance")) %>% 
  mutate(p = "Homogeneous") %>% 
  mutate(p = ifelse((wald_test_p_value * nrow(combinations_df_spatial) < .05) & str_detect(DV2, "no public insurance"), 
                    "Heterogeneous", 
                    p)) %>% 
  mutate(p = ifelse((wald_test_p_value * nrow(combinations_df_spatial) < .05) & !str_detect(DV1, "Medicare"), 
                    "Heterogeneous", 
                    p)) %>% 
  mutate(p = ifelse((wald_test_p_value * nrow(combinations_df_spatial) < .05) & !str_detect(DV2, "no public insurance"), 
                    "Heterogeneous", 
                    p)) %>% 
  mutate(direction = ifelse(DV1_coef - DV2_coef < 0, "-", "+")) %>% 
  mutate(direction = ifelse(p == "Homogeneous", NA, direction)) %>% 
  filter(!str_detect(DV1, "Any public\ninsurance")) %>% 
  ggplot(aes(x = DV1, y = fct_rev(IV), fill = p, label = direction)) +
  geom_tile(color = "white", size=0.33)+
  geom_text(color = "white",
            family = "IBM Plex Sans") +  
  coord_fixed(ratio = .175) +
  scale_y_discrete(expand=c(0, 0)) +
  scale_x_discrete(expand=c(0, 0)) +
  scale_fill_manual(values = 
                      c(
                        "#69688C",
                        "#F39F8D"
                      ),
                    guide = guide_legend(reverse = TRUE)) +
  labs(x = NULL,
       y = NULL) +
  theme_minimal() +
  theme(text = element_text(family = "IBM Plex Sans Light"),
        legend.position = "bottom",
        legend.title = element_blank(),
        legend.text = element_text(margin = ggplot2::margin(l =  0, r = 14))) +
  labs(subtitle = NULL,
       caption = NULL) +
  theme(plot.subtitle = element_text(size = 10, hjust = 0.5),
        legend.box.margin = ggplot2::margin(l = -1.3, t = -.15, unit = "cm"),
        legend.key.size = unit(.45, "cm"))
