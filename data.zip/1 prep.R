########################################################################################################################
# Daniel Tadmon
# Code for "Limits to Helping in a Helping Profession: The Social Context of Psychiatrist Opt-Out from Public Insurance"
# Published in Social Forces 2025 (https://academic.oup.com/sf/advance-article-abstract/doi/10.1093/sf/soaf107/8214142)
########################################################################################################################

library(tidyverse)
library(here)

df <- read_csv(here("data", "df_for_analysis.csv"), col_types = "c")

independent_variables <- c("acs_10_pct_pop_white_non_hispanic", "White (10%)",
                           "acs_10_pct_pop_black_non_hispanic", "Black (10%)",
                           "acs_10_pct_pop_hispanic_all_races", "Hispanic (10%)",
                           "acs_10_pct_pop_asian_non_hispanic", "Asian (10%)",
                           "acs_10_pct_pop_american_indian_non_hispanic", "Native American (10%)",
                           "acs_10_pct_foreign_born", "Foreign born (10%)",
                           "acs_median_hh_income_in_10k", "Median HH income ($10K)",
                           "acs_10_pct_education_high_school_over_25", "High school graduate (10%)",
                           "acs_10_pct_with_broadband_internet", "Broadband internet (10%)",
                           "acs_10_pct_below_poverty", "Below poverty (10%)",
                           "acs_10_pct_uninsured", "Uninsured (10%)",
                           "acs_10_pct_insurance_private", "Private insurance (10%)",
                           "acs_10_pct_insurance_public", "Public insurance (10%)",
                           "acs_10_pct_insurance_medicaid", "Medicaid (10%)",
                           "acs_10_pct_insurance_medicare", "Medicare (10%)",
                           "acs_10_pct_with_disability", "With disability (10%)",
                           "ruca", "RUCA status",
                           "pop_density_1000_ppl_per_sq_mile", "Pop. density (1000 per sq. mile)")

independent_variables <- tibble(variable = independent_variables[seq(1, length(independent_variables), 2)],
                                name = independent_variables[seq(2, length(independent_variables), 2)])

independent_variables_factor <- c(pull(independent_variables, name), 
                                  "Micropolitan", "Small town and rural")

independent_variables_places <- c(
  "place_acs_pop_white_non_hispanic", "White (10%)",
  "place_acs_pop_black_non_hispanic", "Black (10%)",
  "place_acs_pop_hispanic_all_races", "Hispanic (10%)",
  "place_acs_pop_american_indian_non_hispanic", "Native American (10%)",
  "place_acs_pop_asian_non_hispanic", "Asian (10%)",
  "place_acs_10_pct_foreign_born", "Foreign born (10%)",
  "place_acs_median_hh_income_in_10k", "Median HH income ($10K)",
  "place_acs_10_pct_education_high_school_over_25", "High school graduate (10%)",
  "place_acs_10_pct_with_broadband_internet", "Broadband internet (10%)",
  "place_acs_10_pct_below_poverty", "Below poverty (10%)",
  "place_acs_10_pct_uninsured", "Uninsured (10%)",
  "place_acs_10_pct_with_disability", "With disability (10%)",
  "place_acs_10_pct_insurance_private", "Private insurance (10%)",
  "place_acs_10_pct_insurance_public", "Public insurance (10%)",
  "place_acs_10_pct_insurance_medicare", "Medicare (10%)",
  "place_acs_10_pct_insurance_medicaid", "Medicaid (10%)",
  "place_pop_density_1000_ppl_per_sq_mile", "Pop. density (1000 per sq. mile)"
) 

independent_variables_places <- tibble(
  variable = independent_variables_places[seq(1, length(independent_variables_places), 2)],
  name = independent_variables_places[seq(2, length(independent_variables_places), 2)])

dependent_variables <- c(
  "psychiatrist_3sfca", "Psychiatrist access.",
  "psychiatrist_medicaid_3sfca", "Psychiatrist Medicaid access.",
  "psychiatrist_NOT_medicaid_3sfca", "Psychiatrist not accepting Medicaid access.",
  "psychiatrist_medicare_3sfca", "Psychiatrist Medicare access.",
  "psychiatrist_NOT_medicare_3sfca", "Psychiatrist not accepting Medicare access.",
  "psychiatrist_no_public_insurance_3sfca", "Psychiatrist no public insurance access.",
  "psychiatrist_ANY_public_insurance_3sfca", "Psychiatrist any public insurance access.",
  "psychiatrist_3sfca_std", "Psychiatrist access. (Std.)",
  "psychiatrist_medicaid_3sfca_std", "Psychiatrist Medicaid access. (Std.)",
  "psychiatrist_NOT_medicaid_3sfca_std", "Psychiatrist not accepting Medicaid access. (Std.)",
  "psychiatrist_medicare_3sfca_std", "Psychiatrist Medicare access. (Std.)",
  "psychiatrist_NOT_medicare_3sfca_std", "Psychiatrist not accepting Medicare access. (Std.)",
  "psychiatrist_no_public_insurance_3sfca_std", "Psychiatrist no public insurance access. (Std.)",
  "psychiatrist_ANY_public_insurance_3sfca_std", "Psychiatrist any public insurance access. (Std.)",
  "tract_psychiatrist_count", "Psychiatrist count",
  "tract_psychiatrist_medicaid_count", "Psychiatrist Medicaid count",
  "tract_psychiatrist_NOT_medicaid_count", "Psychiatrist not accepting Medicaid count",
  "tract_psychiatrist_medicare_count", "Psychiatrist Medicare count",
  "tract_psychiatrist_NOT_medicare_count", "Psychiatrist not accepting Medicare count",
  "tract_psychiatrist_no_public_insurance_count", "Psychiatrist no public insurance count",
  "tract_psychiatrist_ANY_public_insurance_count", "Psychiatrist any public insurance count")

dependent_variables <- tibble(variable = dependent_variables[seq(1, length(dependent_variables), 2)],
                              name = dependent_variables[seq(2, length(dependent_variables), 2)])

psychiatrist_df <- read_csv(here("data", "combined_psychiatrist_df.csv"))
address_characteristics <- read_csv(here("data", "address_characteristics.csv"))

psychiatrist_df <- psychiatrist_df %>% 
  mutate(license_number = as.character(license_number)) %>%
  left_join(address_characteristics)

rm(address_characteristics)

psychiatrist_df <- psychiatrist_df %>% 
  left_join(
    psychiatrist_df %>% 
      filter(!is.na(census_place_GEOID)) %>% 
      count(census_place_GEOID, sort = TRUE, name = "census_place_n_of_providers_same_profession"), 
    by = c("census_place_GEOID")) 

psychiatrist_df <- psychiatrist_df %>% 
  left_join(
    psychiatrist_df %>% 
      filter(!is.na(census_place_GEOID)) %>% 
      count(census_place_GEOID, sort = TRUE, name = "census_place_n_of_providers_same_professional_category"), 
    by = c("census_place_GEOID")
  )