########################################################################################################################
# Daniel Tadmon
# Code for "Limits to Helping in a Helping Profession: The Social Context of Psychiatrist Opt-Out from Public Insurance"
# Published in Social Forces 2025 (https://academic.oup.com/sf/advance-article-abstract/doi/10.1093/sf/soaf107/8214142)
########################################################################################################################

library(MatchIt)
library(marginaleffects)
library(gt)

sole_providers <- c(1, 2)
not_sole_providers <- c(3, 4, 5)

FCA_boundary <- 20

combined_matrix <- read_csv(here("data", "travel_cost_matrix.gz"))
georgia_pop_by_commuting_props <- read_csv(here("data", "georgia_pop_by_commuting_props.csv"))

combined_matrix <- left_join(combined_matrix, georgia_pop_by_commuting_props) %>% 
  mutate(total_pop = ifelse(is.na(total_pop), 0, total_pop)) %>% 
  mutate(origin = str_remove(origin, "\\_.*")) %>% 
  group_by(origin, destination) %>% 
  summarize(value = Hmisc::wtd.mean(value, weights = total_pop, na.rm = TRUE)) %>% 
  ungroup

tracts_w_providers <- psychiatrist_df %>% 
  filter(census_place_n_of_providers_same_professional_category %in% c(sole_providers, not_sole_providers)) %>% 
  pull(tract_GEOID) %>% 
  unique

combined_matrix <- combined_matrix %>% 
  filter(destination %in% tracts_w_providers) %>% 
  filter(value <= FCA_boundary) 

fca_characteristics <- combined_matrix %>% 
  mutate(origin = as.character(origin)) %>% 
  left_join(df,
            by = c("origin" = "GEOID")) %>% 
  mutate(total_pop = acs_pop) %>% 
  group_by(destination) %>% 
  summarize(across(matches("^acs|3sfca|pop_density_1000_ppl_per_sq_mile"), ~ Hmisc::wtd.mean(.x, weights = acs_pop, na.rm = TRUE)),
            total_pop = sum(total_pop, na.rm = TRUE)) %>% 
  ungroup %>% 
  mutate(acs_pop = total_pop) %>% 
  dplyr::select(-total_pop)

rm(combined_matrix, tracts_w_providers, georgia_pop_by_commuting_props)

covariates_to_summarize <- c(
  "place_acs_pop", 
  "place_pop_density_1000_ppl_per_sq_mile", 
  "place_acs_median_hh_income_in_10k",
  "place_acs_10_pct_education_high_school_over_25",
  "place_acs_10_pct_pop_white_non_hispanic",
  "place_acs_10_pct_insurance_public", 
  "place_acs_10_pct_insurance_medicaid",
  "place_acs_10_pct_insurance_medicare",
  "psychiatrist_3sfca", 
  "pop_density_1000_ppl_per_sq_mile",
  "acs_median_hh_income_in_10k",
  "acs_10_pct_education_high_school_over_25",
  "acs_10_pct_pop_white_non_hispanic",
  "acs_10_pct_insurance_public", 
  "acs_10_pct_insurance_medicaid",
  "acs_10_pct_insurance_medicare",  
  "closest_provider_in_km",
  "hospital_location"
  )

temp_df <- psychiatrist_df %>% 
  mutate(tract_GEOID = as.numeric(tract_GEOID)) %>% 
  left_join(fca_characteristics, by = c("tract_GEOID" = "destination")) 

temp_df <- temp_df %>%
  filter(census_place_n_of_providers_same_professional_category %in% c(sole_providers, not_sole_providers)) %>% 
  mutate(tract_GEOID = as.character(tract_GEOID)) %>% 
  mutate(across(where(is.logical), ~ ifelse(.x, 1, 0))) %>% 
  mutate(across(matches("acs_pop"), ~ .x / 1000)) %>% 
  mutate(sole_provider = ifelse(census_place_n_of_providers_same_professional_category %in% sole_providers, 1, 0)) 

hospital_location_lone_numbers <- temp_df %>% 
  count(hospital_location, sole_provider)

anova_results_psychiatrist <- map_dfr(
  covariates_to_summarize[covariates_to_summarize != "hospital_location"], 
  ~aov(reformulate("sole_provider", response = .x), 
       data = temp_df) %>% 
    broom::tidy() %>% 
    mutate(covariate = .x)) %>% 
  filter(term != "Residuals")

chi_squared_results_psychiatrist <- chisq.test(table( 
  temp_df$hospital_location,  
  temp_df$sole_provider)) %>% 
  broom::tidy()

temp_df <- temp_df %>% 
  mutate(closest_provider_in_km = ifelse(closest_provider_in_km < .02, NA, closest_provider_in_km)) %>% 
  group_by(sole_provider) %>% 
  summarize(across(matches(paste0("^", covariates_to_summarize, "$")), list(
    mean = ~ mean(.x, na.rm = TRUE),
    sd = ~ sd(.x, na.rm = TRUE)
  ))) %>% 
  ungroup %>% 
  mutate(hospital_location_mean = 10 * hospital_location_mean) %>% 
  mutate(across(matches("^closest_provider_in_km"), ~ .x / 1.609))

temp_df <- temp_df %>% 
  pivot_longer(!c("sole_provider")) %>% 
  pivot_wider(names_from = sole_provider, values_from = value) %>% 
  rename(sole_provider = `1`,
         not_sole_provider = '0') %>% 
  mutate(psychiatrist = TRUE) %>%
  pivot_wider(names_from = psychiatrist, values_from = c(sole_provider, not_sole_provider)) %>% 
  mutate(across(where(is.numeric), ~ round(.x, 1))) 

temp_df <- temp_df %>% 
  mutate(type = str_extract(name, "\\_mean$|\\_sd$"),
         name = str_remove(name, "\\_mean$|\\_sd$")) %>%
  pivot_wider(names_from = type, values_from = !c(type, name), names_prefix = "type")

temp_df <- temp_df %>%
  left_join(anova_results_psychiatrist %>%
              dplyr::select(p.value_psychiatrist = p.value, name = covariate)) %>%
  mutate(p.value_psychiatrist = ifelse(name == "hospital_location",
                                       pull(chi_squared_results_psychiatrist, p.value),
                                       p.value_psychiatrist))
         
temp_df$name <- map_chr(temp_df$name, function(x){
  if(any(independent_variables_places$variable == x)) 
    x <- paste0(independent_variables_places$name[independent_variables_places$variable == x], "_place")
                          
  if(any(independent_variables$variable == x)) 
    x <- paste0(independent_variables$name[independent_variables$variable == x], "_fca")
  
  return(x)
})

temp_df <- temp_df %>% 
  mutate(name = case_when(name == "place_acs_pop" ~ "Population (1K)_place",
                          name == "closest_provider_in_km" ~ "Closest colleague (mile)",
                          name == "acs_pop" ~ "Population (1K)_fca",
                          name == "hospital_location" ~ "Hospital location (10%)",
                          name == "place_acs_10_pct_pop_black_non_hispanic" ~ "Black (10%)_place",
                          name == "place_acs_10_pct_pop_white_non_hispanic" ~ "White (10%)_place",
                          name == "psychiatrist_3sfca" ~ "Psychiatrist accessibility_fca",
                          .default = name
                          ))

temp_df <- temp_df %>% 
  mutate(across(ends_with("_mean"), 
                ~paste0(., " (", str_replace(cur_column(), "_mean", "_sd") %>% get(), ")"), 
                .names = "{.col}")) %>%
  dplyr::select(-ends_with("_sd"))

temp_df <- temp_df %>% 
  mutate(across(where(is.numeric), round, 2))

adjust_p <- function (x, toggle_p = TRUE) 
{
  if (toggle_p) {
    x <- ifelse(is.na(x), "...", 
                ifelse(x < 0.001, "*p* < .001", 
                       ifelse(x >= 0.001 & x < 0.01, paste0("*p* = ", round(x, 3)), 
                              ifelse(x >= 0.01 & x < 0.045, paste0("*p* = ", round(x, 2)), 
                                     ifelse(x >= 0.045 & x < 0.05, "*p* < .05", 
                                            ifelse(x >= 0.05, paste0("*p* = ", round(x, 2)), NA))))))
  }
  else {
    x <- ifelse(is.na(x), "...", 
                ifelse(x < 0.001, "< .001", 
                       ifelse(x >= 0.001 & x < 0.01, round(x, 3), 
                              ifelse(x >= 0.01 & x < 0.045, round(x, 2), 
                                     ifelse(x >= 0.045 & x < 0.05, "< .05", 
                                            ifelse(x >= 0.05, round(x, 2), NA))))))
  }
  return(x)
}

temp_df$p.value_psychiatrist <- map(temp_df$p.value_psychiatrist, adjust_p, FALSE)
temp_df$p.value_psychiatrist <- ifelse(!str_detect(temp_df$p.value_psychiatrist, "\\<"), str_remove(temp_df$p.value_psychiatrist, "(?<=\\.\\d\\d)\\d+"), temp_df$p.value_psychiatrist)

colnames(temp_df) <- str_remove(colnames(temp_df), "_type_mean")

temp_df <- temp_df %>% 
  separate(name, into = c("name", "type"), sep = "\\_") %>% 
  mutate(type = ifelse(is.na(type), "provider", type)) %>% 
  mutate(type = case_when(type == "place" ~ "Place",
                          type == "fca" ~ "FCA",
                          type == "provider" ~ "Provider"))  %>% 
  dplyr::select(type, name, sole_provider_TRUE, not_sole_provider_TRUE, p.value_psychiatrist) 

temp_df %>% 
  filter(name != "Years since licensure") %>% 
  gt(rowname_col = "name") %>% 
  tab_header(md("Lone vs. cluster psychiatrist locales' characteristics")) %>% 
  gt::tab_row_group(label = "Place",
                    rows = type == "Place") %>% 
  gt::tab_row_group(label = "FCA",
                    rows = type == "FCA") %>% 
  gt::tab_row_group(label = "Provider",
                    rows = type == "Provider") %>% 
  row_group_order(groups = c("Provider", "Place", "FCA")) %>% 
  gt::cols_hide(type) %>% 
  cols_align(align = "center", columns = -name) %>% 
  gt::cols_label(
    name = "",
    sole_provider_TRUE = paste0(sole_providers, collapse = "-"),
    not_sole_provider_TRUE = paste0(not_sole_providers, collapse = "-"),
    p.value_psychiatrist = md("*P*\nvalue")) %>% 
  tab_spanner(columns = matches("Psychiatrist"),
              label = "Psychiatrist") 

rm(temp_df)

df_for_cem <- left_join(psychiatrist_df,
               fca_characteristics,
               by = c("tract_GEOID" = "destination"))

df_for_cem <- df_for_cem %>% 
  filter(census_place_n_of_providers_same_professional_category %in% c(sole_providers, not_sole_providers)) %>% 
  mutate(sole_provider = ifelse(census_place_n_of_providers_same_professional_category %in% sole_providers, 1, 0)) %>%
  mutate(across(c(medicaid, medicare, no_public_insurance), ~ ifelse(.x, 1, 0))) %>% 
  pivot_longer(c(medicaid, medicare, no_public_insurance)) %>% 
  group_by(name) %>% 
  na.omit() %>% 
  nest()

formula_vector <- c(
  "sole_provider ~ place_pop_density_1000_ppl_per_sq_mile + place_acs_median_hh_income_in_10k + place_acs_10_pct_pop_white_non_hispanic",
  "sole_provider ~ place_pop_density_1000_ppl_per_sq_mile + place_acs_median_hh_income_in_10k + place_acs_10_pct_pop_white_non_hispanic + psychiatrist_3sfca"
)

df_for_cem <- expand_grid(df_for_cem, formula_vector)
df_for_cem$cutpoints <- 3

rm(formula_vector)

df_for_cem <- df_for_cem %>% 
  mutate(formula_vector = map2_chr(formula_vector, name, function(temp_formula, temp_name){
  
    if (str_detect(temp_name, "medicaid")) temp_formula <- str_replace(temp_formula, "\\~", "~ place_acs_10_pct_insurance_medicaid +")
    if (str_detect(temp_name, "medicare")) temp_formula <- str_replace(temp_formula, "\\~", "~ place_acs_10_pct_insurance_medicare +")
    if (str_detect(temp_name, "public")) temp_formula <- str_replace(temp_formula, "\\~", "~ place_acs_10_pct_insurance_public +")
    
    return(temp_formula)
  
}))

df_for_cem <- df_for_cem %>% 
  mutate(matched = pmap(list(data, formula_vector, cutpoints), function(temp_data, temp_formula_vector, temp_cutpoints){
    
    MatchIt::matchit(as.formula(temp_formula_vector), 
                          data = temp_data,
                          method = "cem", 
                          cutpoints = temp_cutpoints) 
  }
  ))

df_for_cem <- df_for_cem %>% 
  mutate(matched_data = map(matched, MatchIt::match.data))

df_for_cem <- df_for_cem %>% 
  mutate(model_bivariate = map(matched_data, function(temp_matched){
    
    glm(value ~ sole_provider,
             family = quasibinomial(),
             weights = weights,
             data = temp_matched) 
    
  })) 

df_for_cem <- df_for_cem %>% 
  mutate(broomed_model_bivariate = map(model_bivariate, function(x){
    
    glance_object <- broom::glance(x) 
    
    tidy_object <- broom::tidy(x, conf.int = TRUE, exponentiate = TRUE) %>% 
      filter(term != "(Intercept)") 
    
    return(bind_cols(tidy_object, glance_object))
    
  }))

df_for_cem <- df_for_cem %>% 
  mutate(avg_comparison_bivariate = map2(model_bivariate, matched_data, function(x, y){
    
    marginaleffects::avg_comparisons(x, 
                                     variables = "sole_provider",
                                     vcov = ~subclass,
                                     newdata = subset(y, sole_provider == 1),
                                     comparison = "lnoravg",
                                     wts = "weights")
  
  }
  ))

df_for_cem <- df_for_cem %>% 
  mutate(model_multivariate = map2(matched_data, formula_vector, function(temp_matched, temp_formula_vector){
    
    temp_formula_vector <- str_replace(temp_formula_vector, "sole_provider \\~ ", "value ~ sole_provider + ")
    
    glm(as.formula(temp_formula_vector),
             family = quasibinomial(),
             weights = weights,
             data = temp_matched) 
    
  })) 

df_for_cem <- df_for_cem %>% 
  mutate(broomed_model_multivariate = map(model_multivariate, function(x){
    
    glance_object <- broom::glance(x) 
    
    tidy_object <- broom::tidy(x, conf.int = TRUE, exponentiate = TRUE) %>% 
      filter(term != "(Intercept)") 
    
    return(bind_cols(tidy_object, glance_object))
    
  }))

df_for_cem <- df_for_cem %>% 
  mutate(avg_comparison_multivariate = map2(model_multivariate, matched_data, function(x, y){
    
    marginaleffects::avg_comparisons(x, 
                                     variables = "sole_provider",
                                     vcov = ~subclass,
                                     newdata = subset(y, sole_provider == 1),
                                     comparison = "lnoravg",
                                     wts = "weights")
  
  }
  ))

df_for_cem <- df_for_cem %>% 
  unnest(avg_comparison_multivariate, names_sep = "multivariate_") %>% 
  unnest(avg_comparison_bivariate, names_sep = "bivariate_") 

colnames(df_for_cem) <- str_remove_all(colnames(df_for_cem), "avg_comparison_bivariate|avg_comparison_multivariate")

df_for_GT_cem <- df_for_cem %>% 
  mutate(discarded = map_int(matched, ~ sum(.x$weights < .001))) %>%
  mutate(nobs_matched = map_int(matched, ~ nrow(.x$X)) - discarded) %>% 
  dplyr::select(name, formula_vector, 
         bivariate_estimate, 
         bivariate_statistic,
         bivariate_p.value, 
         bivariate_conf.low, bivariate_conf.high,
         multivariate_estimate, 
         multivariate_statistic,
         multivariate_p.value,
         multivariate_conf.low, multivariate_conf.high,
         nobs_matched
         ) %>% 
  mutate(across(matches("estimate|conf.low|conf.high"), exp)) %>% 
  mutate(formula_vector = str_remove(formula_vector, "\\_medicaid|\\_medicare|\\_public")) %>% 
  mutate(across(matches("p.value"), ~ map(.x, adjust_p, FALSE))) %>% 
  mutate(across(where(is.numeric), round, 2)) %>% 
  mutate(bivariate_statistic = paste0(bivariate_conf.low, ", ", bivariate_conf.high),
         multivariate_statistic = paste0(multivariate_conf.low, ", ", multivariate_conf.high)) %>% 
  dplyr::select(-c(bivariate_conf.low, bivariate_conf.high, multivariate_conf.low, multivariate_conf.high)) %>% 
  rename(bivariate_ci = bivariate_statistic,
         multivariate_ci = multivariate_statistic) %>% 
  pivot_wider(names_from = c(name), values_from = !c(formula_vector, name))

df_for_GT_cem %>% 
  dplyr::select(formula_vector, 
                matches("medicaid"), matches("medicare"),
         matches("insurance"), matches("nobs_matched")) %>% 
  gt(rowname_col = "formula_vector") %>% 
  tab_header("Bi- and Multivariate marginal effects of providers' sole status") %>% 
  tab_options(table.font.siz = pct(40)) %>% 
  fmt_missing(columns = everything(), missing_text = "...") %>% 
  cols_label_with(fn = function(x){
    if (str_detect(x, "estimate")) x <- md("_\U03B2_")
    if (str_detect(x, "p\\.value")) x <- md("*p*")
    if (str_detect(x, "_ci_")) x <- md("95% CI")
    if (str_detect(x, "nobs_matched")) x <- md("*N*")
    return(x)
  }) %>% 
  cols_align(align = "center", columns = -formula_vector) %>% 
  tab_style(style = list(
    cell_borders(sides = 'right', style = 'solid', color = "grey90", weight = px(1.5))),
    locations = cells_body(columns = matches("^p."))) %>% 
  tab_spanner(columns = matches("no\\_public\\_insurance"),
              label = "No public insurance", level = 3) %>% 
  tab_spanner(columns = matches("medicaid"),
              label = "Medicaid", level = 3) %>% 
  tab_spanner(columns = contains("medicare"),
              label = "Medicare", level = 3) %>% 
  tab_spanner(columns = contains("bivariate"),
              label = "Bivariate", level = 2) %>% 
  tab_spanner(columns = contains("multivariate"),
              label = "Multivariate", level = 2) %>% 
  tab_style(style = list(
    cell_borders(sides = 'right', style = 'solid', color = "grey90", weight = px(1))),
    locations = cells_body(columns = matches("p.value"))) %>% 
  tab_style(style = list(
    cell_borders(sides = 'right', style = 'solid', color = "grey90", weight = px(1.5))),
    locations = cells_body(columns = matches("nobs_matched|cutpoints"))) 

selected_CEM_model <- df_for_cem %>% 
  filter(str_detect(formula_vector, "sole_provider \\~ place_acs_10_pct_insurance.+ \\+ place_pop_density_1000_ppl_per_sq_mile \\+ place_acs_median_hh_income_in_10k \\+ place_acs_10_pct_pop_white_non_hispanic$"))

x <- map_df(c("medicaid", "medicare", "no_public_insurance"), function(x){
  tibble(
    treatment = selected_CEM_model[selected_CEM_model$name == x, ]$matched[[1]]$treat,
    subclass = selected_CEM_model[selected_CEM_model$name == x, ]$matched[[1]]$subclass,
    weights = selected_CEM_model[selected_CEM_model$name == x, ]$matched[[1]]$weights
  ) %>% 
    filter(!is.na(subclass)) %>% 
    bind_cols(tibble(outcome = selected_CEM_model[selected_CEM_model$name == x, ]$matched_data[[1]]$value,
                     model = x)) 
})

x <- x %>% 
  mutate(outcome = ifelse(model == "no_public_insurance", abs(outcome - 1), outcome))

x <- x %>% 
  group_by(subclass, treatment, model) %>% 
  summarize(outcome = Hmisc::wtd.mean(outcome, weights = weights)) %>% 
  left_join(x %>% 
              group_by(subclass, model) %>% 
              summarize(w = sum(weights))) %>% 
  ungroup %>% 
  mutate(w = w / max(w)) %>% 
  mutate(model = case_when(model == "medicaid" ~ "Medicaid",
                           model == "medicare" ~ "Medicare",
                           model == "no_public_insurance" ~ "Any public insurance")) %>% 
  mutate(model = factor(model, levels = c("Medicaid",
                                          "Medicare",
                                          "Any public insurance")))

x %>% 
  ggplot(aes(x = treatment, y = outcome, group = subclass, alpha = w / 2)) +
  facet_wrap( ~ model) + 
  geom_line() +
  geom_point(size = .5) +
  geom_smooth(data = x %>% 
                mutate(w = round((20 * w) / min(w))) %>% 
                uncount(w),
              inherit.aes = FALSE,
              method="glm", method.args=list(family="binomial"), 
              aes(x = treatment, y = outcome),
              fill = "#9DBFAF",
              se = TRUE,
              linetype = 2,
              size = .75,
              alpha = .35,
              color = "black") +
  xlab("N providers") +
  scale_linewidth(range = c(.33, .66)) +
  scale_alpha(range = c(.2, .8)) +
  guides(alpha = "none") + 
  scale_y_continuous(labels = scales::percent_format(scale = 100)) +
  scale_x_continuous(breaks = c(0, 1),
                     labels = c("Cluster", "Lone")
  ) +
  theme_minimal() +
  theme(text = element_text(family = "IBM Plex Sans Light"),
        panel.spacing.x = unit(1.45, "line"),
        axis.title = element_blank(),
        axis.text.y = element_text(size = 7)
  )