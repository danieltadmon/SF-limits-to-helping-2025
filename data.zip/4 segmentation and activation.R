########################################################################################################################
# Daniel Tadmon
# Code for "Limits to Helping in a Helping Profession: The Social Context of Psychiatrist Opt-Out from Public Insurance"
# Published in Social Forces 2025 (https://academic.oup.com/sf/advance-article-abstract/doi/10.1093/sf/soaf107/8214142)
########################################################################################################################

library(glmmTMB)

df_for_permutation_test <- psychiatrist_df %>% 
  filter(census_place_n_of_providers_same_professional_category %in% c(sole_providers, not_sole_providers)) %>% 
  mutate(sole_provider = ifelse(census_place_n_of_providers_same_professional_category %in% sole_providers, 1, 0)) %>%
  mutate(across(c(medicaid, medicare, no_public_insurance), ~ ifelse(.x, 1, 0))) %>% 
  dplyr::select(census_place_GEOID, medicaid, medicare, no_public_insurance, sole_provider)

n_draws <- 10000

insurance_medicaid <- df_for_permutation_test %>% 
  filter(sole_provider == 0) %>% 
  pull(medicaid)

insurance_medicare <- df_for_permutation_test %>% 
  filter(sole_provider == 0) %>% 
  pull(medicare)

n <- length(insurance_medicaid)

places <- df_for_permutation_test %>% 
  filter(sole_provider == 0) %>% 
  pull(census_place_GEOID) 

n_places <- places %>% 
  unique %>% 
  length

zeros <- NULL
set.seed(1)

for (i in 1:n_draws){
  
  temp <- tibble(places = places,
                 medicaid = insurance_medicaid[sample(1:n, n, replace = FALSE)],
                 medicare = insurance_medicare[sample(1:n, n, replace = FALSE)])
  
  zeros <- c(
    zeros,
    
    temp %>% 
      group_by(places) %>% 
      summarize(medicaid = sum(medicaid),
                medicare = sum(medicare)) %>% 
      filter(medicaid == 0,
             medicare == 0) %>% 
      nrow
  )
}

p_value <- (n_draws - sum(zeros == 0)) / n_draws

places_shapefile <- georgia_tracts <- st_read(here("data", "Census_Georgia_places_tl_2023_13_place", "tl_2023_13_place.shp"))
places_centroids <- st_centroid(places_shapefile)
georgia_tracts <- st_read(here("data", "Georgia 2023 Census tract SHP", "tl_2023_13_tract.shp"))

x <- sf::st_intersects(places_centroids, georgia_tracts)

places_centroids$tract_geoid <- georgia_tracts$GEOID[unlist(x)]

cluster_places <- psychiatrist_df %>% 
  filter(census_place_n_of_providers_same_profession %in% not_sole_providers) %>% 
  drop_na(census_place_GEOID) %>% 
  pull(census_place_GEOID) %>% 
  unique

medicaid_places <- psychiatrist_df %>% 
  filter(medicaid) %>%
  drop_na(census_place_GEOID) %>% 
  pull(census_place_GEOID) %>% 
  unique %>% 
  setdiff(cluster_places)

medicare_places <- psychiatrist_df %>% 
  filter(medicare) %>%
  drop_na(census_place_GEOID) %>% 
  pull(census_place_GEOID) %>% 
  unique %>% 
  setdiff(cluster_places)

cluster_to_medicaid <- expand_grid(cluster_places, medicaid_places) %>% 
  mutate(cluster_places = as.character(cluster_places),
         medicaid_places = as.character(medicaid_places))

cluster_to_medicaid <- cluster_to_medicaid %>% 
  inner_join(places_centroids %>% 
               st_drop_geometry() %>% 
               dplyr::select(GEOID, tract_geoid), 
             by = c(cluster_places = "GEOID")) %>% 
  rename(cluster_tracts = tract_geoid) %>% 
  inner_join(places_centroids %>% 
               st_drop_geometry() %>% 
               dplyr::select(GEOID, tract_geoid), 
             by = c(medicaid_places = "GEOID")) %>% 
  rename(medicaid_tracts = tract_geoid)

cluster_to_medicare <- expand_grid(cluster_places, medicare_places) %>% 
  mutate(cluster_places = as.character(cluster_places),
         medicare_places = as.character(medicare_places))

cluster_to_medicare <- cluster_to_medicare %>% 
  inner_join(places_centroids %>% 
               st_drop_geometry() %>% 
               dplyr::select(GEOID, tract_geoid), 
             by = c(cluster_places = "GEOID")) %>% 
  rename(cluster_tracts = tract_geoid) %>% 
  inner_join(places_centroids %>% 
               st_drop_geometry() %>% 
               dplyr::select(GEOID, tract_geoid), 
             by = c(medicare_places = "GEOID")) %>% 
  rename(medicare_tracts = tract_geoid)

travel_cost_matrix <- read_csv(here("data", "travel_cost_matrix.gz")) %>% 
  filter(str_detect(origin, "car$")) %>% 
  mutate(origin = str_remove(origin, "\\_car$")) %>% 
  mutate(origin = as.character(origin),
         destination = as.character(destination))

cluster_to_medicaid <- inner_join(cluster_to_medicaid, travel_cost_matrix, 
                                  by = c("cluster_tracts" = "origin",
                                         "medicaid_tracts" = "destination")) %>% 
  dplyr::select(-cluster_tracts, -medicaid_tracts)

cluster_to_medicare <- inner_join(cluster_to_medicare, travel_cost_matrix, 
                                  by = c("cluster_tracts" = "origin",
                                         "medicare_tracts" = "destination")) %>% 
  dplyr::select(-cluster_tracts, -medicare_tracts)

cluster_to_medicaid <- cluster_to_medicaid %>% 
  group_by(cluster_places) %>% 
  slice_min(value, n = 1)

cluster_to_medicare <- cluster_to_medicare %>% 
  group_by(cluster_places) %>% 
  slice_min(value, n = 1)

distance_df <- cluster_to_medicaid %>% 
  dplyr::select(census_place_GEOID = cluster_places,
                min_medicaid_distance = value) %>% 
  inner_join(cluster_to_medicare %>% 
               dplyr::select(census_place_GEOID = cluster_places,
                             min_medicare_distance = value)) %>% 
  mutate(census_place_GEOID = as.double(census_place_GEOID))

df_for_permutation_test2 <- df_for_permutation_test %>% 
  filter(sole_provider == 0) %>% 
  left_join(distance_df)

insurance_medicaid <- df_for_permutation_test2 %>% 
  dplyr::select(medicaid, min_medicaid_distance)

insurance_medicare <- df_for_permutation_test2 %>% 
  dplyr::select(medicare, min_medicare_distance)

n <- nrow(insurance_medicaid)

places <- df_for_permutation_test2 %>% 
  pull(census_place_GEOID) 

places_medicaid_prop <- df_for_permutation_test2 %>% 
  dplyr::select(census_place_GEOID) %>% 
  inner_join(psychiatrist_df %>% 
               dplyr::select(census_place_GEOID, place_acs_10_pct_insurance_medicaid) %>% 
               distinct) %>% 
  pull(place_acs_10_pct_insurance_medicaid)

places_medicare_prop <- df_for_permutation_test2 %>% 
  dplyr::select(census_place_GEOID) %>% 
  inner_join(psychiatrist_df %>% 
               dplyr::select(census_place_GEOID, place_acs_10_pct_insurance_medicare) %>% 
               distinct) %>% 
  pull(place_acs_10_pct_insurance_medicare)

n_places <- places %>% 
  unique %>% 
  length

medicaid_distance <- NULL
medicare_distance <- NULL

for (i in 1:(n_draws * 1.25)){
  
  temp <- tibble(places = places,
                 
                 places_medicaid_prop = places_medicaid_prop,
                 places_medicare_prop = places_medicare_prop,
                 
                 medicaid = insurance_medicaid %>% 
                   sample_n(n, replace = FALSE) %>% 
                   pull(medicaid),
                 
                 medicare = insurance_medicare %>% 
                   sample_n(n, replace = FALSE) %>% 
                   pull(medicare)) %>% 
    
    mutate(medicaid = medicaid * (places_medicaid_prop / (places_medicaid_prop + places_medicare_prop)),
           medicare = medicare * (places_medicare_prop / (places_medicaid_prop + places_medicare_prop)))
  
  distance_to_medicaid <- temp %>% 
    group_by(places) %>% 
    summarize(medicaid = sum(medicaid)) %>% 
    ungroup %>% 
    filter(medicaid == 0) %>% 
    left_join(distance_df, by = c("places" = "census_place_GEOID")) %>% 
    inner_join(psychiatrist_df %>% 
                 dplyr::select(census_place_GEOID, place_acs_pop) %>% 
                 distinct,
               by = c("places" = "census_place_GEOID")) %>% 
    summarize(min_medicaid_distance = Hmisc::wtd.mean(min_medicaid_distance, weights = place_acs_pop)) %>% 
    pull(min_medicaid_distance)
  
  distance_to_medicare <- temp %>% 
    group_by(places) %>% 
    summarize(medicare = sum(medicare)) %>% 
    ungroup %>% 
    filter(medicare == 0) %>% 
    left_join(distance_df, by = c("places" = "census_place_GEOID")) %>% 
    inner_join(psychiatrist_df %>% 
                 dplyr::select(census_place_GEOID, place_acs_pop) %>% 
                 distinct,
               by = c("places" = "census_place_GEOID")) %>% 
    summarize(min_medicare_distance = Hmisc::wtd.mean(min_medicare_distance, weights = place_acs_pop)) %>% 
    pull(min_medicare_distance)
  
  if(is.na(distance_to_medicaid)) {
    medicaid_distance <- c(medicaid_distance, NA)
  } else {
    if(distance_to_medicaid > 0) medicaid_distance <- c(medicaid_distance, distance_to_medicaid)
  }
  
  if(is.na(distance_to_medicare)) {
    medicare_distance <- c(medicare_distance, NA)
  } else {
    if(distance_to_medicare > 0) medicare_distance <- c(medicare_distance, distance_to_medicare)
  }
}

temp2 <- tibble(
  medicaid = medicaid_distance,
  medicare = medicare_distance) %>% 
  mutate(medicaid = ifelse(is.na(medicaid), 0, medicaid),
         medicare = ifelse(is.na(medicare), 0, medicare)) %>% 
  mutate(distance = (medicaid + medicare) / 2) 

temp2 <- temp2 %>% 
  filter(distance > 0) %>%
  sample_n(sum(zeros == 0)) %>% 
  arrange(distance) %>% 
  add_rownames(var = "n") %>% 
  mutate(n = as.numeric(n)) %>% 
  mutate(n = (n / (sum(zeros == 0))) * 1000)

mean_temp <- mean(temp2$distance)
sd_temp <- sd(temp2$distance)

temp2 %>%
  ggplot(aes(x = n, y = distance)) +
  geom_col() +
  annotate("segment", x = 1, xend = 1000, y = mean_temp, yend = mean_temp, 
           color = "grey30", size = .8, linetype = 2) +
  theme_minimal() +
  scale_x_continuous(labels = scales::percent_format(scale = 1/10)) +  
  scale_y_continuous(breaks = seq(0, 80, 10)) +
  labs(x = "Simulations",
       y = "Drive time (minutes)") +
  theme(
    text = element_text(family = "IBM Plex Sans Light"),
    axis.title.x = element_text(vjust = -1),
    axis.title.y = element_text(vjust = 1.5)
  )

model_multivariate <- glmmTMB::glmmTMB(cbind(medicaid, medicare) ~ 1 + (1 | census_place_GEOID),
                                       family = binomial(link = "logit"),
                                       data = df_for_permutation_test %>% 
                                         filter(sole_provider == 0))

model_multivariate2 <- glmmTMB::glmmTMB(cbind(medicaid, medicare) ~ 1 + (0 + medicaid | census_place_GEOID) + (0 + medicare | census_place_GEOID), 
                                        family = binomial(link = "logit"),
                                        data = df_for_permutation_test %>% 
                                          filter(sole_provider == 0))

model_null <- glmmTMB::glmmTMB(cbind(medicaid, medicare) ~ 1,
                               family = binomial(link = "logit"),
                               data = df_for_permutation_test %>% 
                                 filter(sole_provider == 0))

anova(model_multivariate2, model_null, 
      test = "LRT")
